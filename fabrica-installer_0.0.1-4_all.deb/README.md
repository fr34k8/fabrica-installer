fabrica-lvm-installer
=======================

Uno script per l'installazione di fabrica-ve ed i suoi complementi.

Derivato dai tools per [refracta|http://www.ibiblio.org/refracta/] di fsmithred  https://github.com/fsmithred/refracta

 git clone https://github.com/pieroproietti/fabrica-lvm-installer.git
 
 to do:
 -ricostruire la home dell'user corrente, oppure creare utente
 
 -NON funzionano ancora la configurazione di nameserver e search in /etc/resolv.conf
 
 -La procedura di creazione del .deb dpkg -b fabrica-lvm-installer DEBS copia i file
  README e LICENZE nella root, va modificata la struttura della repository 
  
  -Rimessa la copia di home per evitare problemi al momento
  
 
 


